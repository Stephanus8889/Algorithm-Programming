#include<stdio.h>
#include<ctype.h>
#include<string.h>

// Nama:Stephanus Nicholas
// NIM:2301864524

char kalimat[100];
int a=0;
char temp_kriteria[100];
char pencarian[100]="NULL";
char nilai[100]="NULL";
char kriteria[50][100];
char kalimat2[100];
int pembatas=0;
char id[100];
char name[100];
char kota[100];
char gender[5];
char car[5];
char property[5];
int cek=0;
char * token;

void pengecekan(){
	token = strtok(kalimat, " ");
	a=0;
	while(token != NULL){
		if(a==1){
			strcpy(temp_kriteria, token);
		}
		else if(a==3){
			strcpy(pencarian, token);
		}
		else if(a==5){
			strcpy(nilai, token);
		}
//		printf("%s\n", token);
		token = strtok(NULL, " ");
		a++;
	}
}

void pemisah(){
	token = strtok(temp_kriteria, ",");
	while(token != NULL){
		if(strcmp(token, "*")==0){
			strcpy(kriteria[0], "first_name");
			strcpy(kriteria[1], "city");
			strcpy(kriteria[2], "gender");
			strcpy(kriteria[3], "has_car");
			strcpy(kriteria[4], "has_property");
			pembatas=5;
			break;
		}
		strcpy(kriteria[pembatas], token);
		token = strtok(NULL, ",");
		pembatas++;
	}
}
int main(){
	FILE*fp;
	fp=fopen("customer_app_data.csv", "r");
	printf("Query: ");
	scanf("%[^\n]",kalimat);getchar();
	printf("Result:\n");
	pengecekan();
	pemisah();
	
	while(!feof(fp)){
		fscanf(fp,"%s", kalimat2);
		a=0;
		token= strtok(kalimat2,";");
			while(token != NULL){
				if(a==0){
					strcpy(id, token);
				}
				else if(a==1){
					strcpy(name, token);
				}
				else if(a==2){
					strcpy(kota, token);
				}
				else if(a==3){
					strcpy(gender, token);
				}
				else if(a==4){
					strcpy(car, token);
				}
				else if(a==5){
					strcpy(property, token);
				}
				token = strtok(NULL, ";");
				a++;
			}
		if(strcmp(id, "id")==0){
			continue;
		}
		else if(strcmp(name,"first_name")==0){
			continue;
		}
		else if(strcmp(kota, "city")==0){
			continue;
		}
		else if(strcmp(gender, "gender")==0){
			continue;
		}
		else if(strcmp(car, "has_car")==0){
			continue;
		}
		else if(strcmp(property, "has_property")==0){
			continue;
		}
		
		if(strcmp(pencarian, "id")==0 && strcmp(id, nilai)!=0){
			continue;
		}
		else if(strcmp(pencarian, "first_name")==0 && strcmp(name, nilai)!=0){
			continue;
		}
		else if(strcmp(pencarian, "city")==0 && strcmp(kota, nilai)!=0){
			continue;
		}
		else if(strcmp(pencarian, "gender")==0 && strcmp(gender, nilai)!=0){
			continue;
		}
		else if(strcmp(pencarian, "has_car")==0 && strcmp(car, nilai)!=0){
			continue;
		}
		else if(strcmp(pencarian, "has_property")==0 && strcmp(property, nilai)!=0){
			continue;
		}
		for(int j=0; j<pembatas; j++){
			if(strcmp(kriteria[j], "id")==0){
				printf("id: %s", id);
			}
			else if(strcmp(kriteria[j], "first_name")==0){
				printf("first_name: %s", name);
			}
			else if(strcmp(kriteria[j], "city")==0){
				printf("city: %s", kota);
			}
			else if(strcmp(kriteria[j], "gender")==0){
				printf("gender: %s", gender);
			}
			else if(strcmp(kriteria[j], "has_car")==0){
				printf("has_car: %s", car);
			}
			else if(strcmp(kriteria[j], "has_property")==0){
				printf("has_property: %s", property);
			}
			
			if(j<pembatas-1){
				printf("; ");
			}
			else if(j==pembatas-1){
				printf("\n");
			}
		}
		cek++;
	}
	if(cek==0){
		printf("Data Not Found!\n");
	}
	fclose(fp);
	return 0;
}
